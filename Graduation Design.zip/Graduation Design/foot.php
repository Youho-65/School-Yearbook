<html>
<head>
    <title>顺德职业技术学院同学录系统</title>
    <meta http-equiv="Content-Type" content="text/css;charset=utf-8" >
<style>
    .foot{
        width: 1690px;
        position: fixed;
        bottom: 0px;
    }
    .pic1 p{
        position: absolute;
        top: 10px;
        align-content: center;
        right: 20px;
        font-size:large;
        font-style: oblique;
        color: deepskyblue;
        margin-top: 50px;
    }




</style>
<body>
<div class="foot">
    <div class="pic1">
        <tr>
            <td align="center" height="120">
                <img src="image/head.jpg" width="1690" height="90">
            </td>
        </tr>
        <p>梁有贺——版权所有</p>
    </div>
</div>
</body>
</head>
</html>
