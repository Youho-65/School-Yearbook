<?php
include 'head.php';
?>
<html>
<style>
    .reg{
        margin-left: 400px;
    }
    .top{
        margin-left: 300px;
        font-size: x-large;
    }
    .top1{
        margin-left: 250px;
        font-size: small;
    }
    .center{
        width: auto;
        height: 425px;
        background-color: peachpuff;
        border: solid 1px;
    }
    .right{
       float: right;
        width: 575px;
       /* background-color: #8AC007;*/
    }
    .left{
        text-align: center;
        float: left;
        width: 200px;
       font-size:16px;
       /* background-color: red;*/
    }
    .left div{
        margin-top: 2px;
    }
    .right div{
        margin-top: 1px;
    }
</style>
<script language="JavaScript">
    function Judge(thForm1) {
        if(thForm1.userpass1.value==""){
            alert("请输入密码!");
            thForm1.userpass1.focus();
            return(false);
        }//验证密码是否为空
        if(thForm1.userpass1.value.length<3 ||thForm1.userpass1.value.length>20){
            alert("密码过长!");
            thForm1.userpass1.focus();
            return (false);
        }//验证密码长度
        if(thForm1.userpass1.value != thForm1.userpass2.value){
            alert("两次密码不正确，请确认!");
            thForm1.userpass1.focus();
            thForm1.userpass2.focus();
            return (false);
        }//确认密码两次是否相同
        if(thForm1.realname.value == ""){
            alert("请填写你的真实姓名!")
            thForm1.realname.focus();
            return (false);
        }//确认是否填写了真实姓名
        if(thForm1.userbdy.value == ""){
            alert("请选择你的出生年月日!")
            thForm1.userbdy.focus();
            return (false);
        }//确认是否选择了生日
        if(thForm1.usermail.value == ""){
            alert("请填写你的邮箱地址!")
            thForm1.usermail.focus();
            return (false);
        }//确认是否填写了邮箱
        if(thForm1.useradd.value == ""){
            alert("请填写你的住址!")
            thForm1.useradd.focus();
            return (false);
        }//确认是否填写了住址


}
</script>
<head>
<body>
<div class="reg" style="width: 778px" >
    <div class="top"><b>用户注册</b></div>
    <div class="top1">欢迎你,<?echo $_GET['username'];?>!,请填写属于你的个人资料。</div>
    <form action="reginfo.php" method="post" onsubmit="return Judge(this)">
        <div class="center">
            <div class="left">
                <div>用户账号:</div>
                <div>密码:</div>
                <div>确认密码:</div>
                <div>真实姓名:</div>
                <div>生日:</div>
                <div>性别:</div>
                <div>籍贯:</div>
                <div>爱好:</div>
                <div>QQ:</div>
                <div>E-mail:</div>
                <div>手机:</div>
                <div>住址:</div>
                <div>个人简介:</div>
            </div>
            <div class="right">
                <div><?echo $_GET['username'];?><input type="hidden" name="username" value=""><font color="red" size="2">(若要修改点击<a href="javascript:history.back(1)">返回</a>)</font></div>
                <div><input type="password" name="userpass1" ><font color="red" size="2">(英文、数字或下划线,长度在3~20之间)</font></div>
                <div><input type="password" name="userpass2" ><font color="red" size="2">(英文、数字或下划线,长度在3~20之间)</font></div>
                <div><input type="text" name="realname"></div>
                <div><input type="date" value="" name="userbdy"></div>
                <div style="float: left"><input id="man" type="radio"  name="male">男</div>
                <div style="float: right;margin-right: 501px"><input id="woman" type="radio"  name="female">女</div>
                <div>
                    <select name="userfrom">
                        <option value="北京">北京</option>
                        <option value="天津">天津</option>
                        <option value="上海">上海</option>
                        <option value="重庆">重庆</option>
                        <option value="河北">河北</option>
                        <option value="山西">山西</option>
                        <option value="陕西">陕西</option>
                        <option value="吉林">吉林</option>
                        <option value="辽宁">辽宁</option>
                        <option value="黑龙江">黑龙江</option>
                        <option value="江苏">江苏</option>
                        <option value="浙江">浙江</option>
                        <option value="安徽">安徽</option>
                        <option value="福建">福建</option>
                        <option value="台湾">台湾</option>
                        <option value="江西">江西</option>
                        <option value="山东">山东</option>
                        <option value="河南">河南</option>
                        <option value="湖北">湖北</option>
                        <option value="湖南">湖南</option>
                        <option value="广东">广东</option>
                        <option value="海南">海南</option>
                        <option value="四川">四川</option>
                    </select>
                </div>
                <div><input type="text" name="userhobby" value=""></div>
                <div><input type="text" name="userqq" value="" ></div>
                <div><input type="text" name="usermail" value=""  ><font color="red" size="2">(用于密码找回)</div>
                <div><input type="text" name="usermobi" value=""></div>
                <div><input type="text" name="useradd" value=""></div>
                <div><textarea rows="8" cols="77" name="userwords"></textarea></div>
                <div style="float: left;margin-left: 120px"><input type="submit" name="" value="提交"></div>
                <div style="float: right;margin-right: 300px"><input type="submit" name="" value="重写"></div>
            </div>
        </div>
    </form>
</div>
</body>
</head>
</html>