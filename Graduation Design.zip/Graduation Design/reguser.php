<?php
include_once 'head.php';
if (isset($_POST['username'])) {
    $name = $_POST['username'];
    $db = mysqli_connect("localhost", "root", "root", "alumni");//数据库连接
    $sql = " select * from tb_user where username  = '$name' ";//sql语句
    $res = mysqli_query($db, $sql);//执行sql语句
    $row = mysqli_fetch_assoc($res);//把结果给到row变量
    $message="";
    if ($name == $row["username"]) {
        $message .="用户名已存在!<br>";
    } else {
       header("location:reginfo.php?username=$name");
    }
}
?>
<html>
<head>
<style>
    .reguser{
        margin-left: 450px;
        margin-top: 100px;
    }
    .top {
        font-style: oblique;
   /*     border: solid 1px ;*/
    }
    .top b{
       margin-left: 260px;
    }
    .textline{
        width: 300px;
        height: 150px;
        background-color: chartreuse;
        margin-left: 180px;
        margin-top: 50px;
    }
    .sumbit{
        margin-left: 120px;
    }
    .rcorners{
        margin-top: 10px;
        border-radius: 25px;
        border: 2px solid #8AC007;
        padding: 10px;
        width:92%;
        height: 50px;
    }
    .tip{
        margin-top: 20px;
    }
    .error{
        float: left;
    }
</style>
<body>
<div class="reguser"  style="background-color: lightskyblue;width: 600px;height: 300px">
    <div class="reguser1">
        <div class="top"><b>用户注册</b></div>
        <form name="form" action="reguser.php" method="post" onSubmit="return Juge(this)">
            <div class="textline">
                <b>用户名:</b>
                <input type="text" name="username" class="text">
                <div class="rcorners" style="font-size: x-small">
                    <font color="red" size="3px"> ·</font>用户名长度为3-15位,不去区分大小写.
                    <div class="tip" style="font-size: x-small">
                        <font color="red" size="3px"> ·</font>用户名仅由英文字母,数字和下划线构成,不能有空格.
                    </div>
                </div>
                <div class="sumbit" >
                    <input type="submit" name="submit" value="下一步" >
                </div>
                <div class="error"><font color="red" size="2px"><?echo $message; ?></font></div>
            </div>
        </form>
    </div>
</div>
</body>
</head>
</html>
