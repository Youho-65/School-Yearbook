<?php
include_once 'foot.php';
?>
<html>
<head>
    <title>顺德职业技术学院同学录系统</title>
    <meta http-equiv="Content-Type" content="text/css;charset=utf-8" >
<style>
    .header{
        width: auto;
        height: 120px;
        border: solid 1px white;
        position: relative;

    }
    .pic img{
        width: 100%;
        display: block;
    }
    .pic p{
        position: absolute;
        top: 10px;
        align-content: center;
        right: 20px;
        font-size: 50px;
        font-style: oblique;
        color: deepskyblue;
    }
    .time{
        float: right;
    }
    .second{
        width: auto;
        height: 20px;
        margin-top: 5px;
    }
</style>
<script language="JavaScript">
    function Juge(theForm){
        if(theForm.username.value == ""){
            alert("请输入用户名！");
            theForm.user_new_id.focus();
            return(false);
        }//是否输入用户名
        if(theForm.username.value.length<3 || theForm.username.value.length>15){
            if(theForm.username.value.length<3)alert("你的用户名太短了！");
            if(theForm.username.value.length>15)alert("你的用户名太长了！");
            theForm.username.focus();
            return (false);
        }//用户名长短
    }
</script>

<body bgcolor="#ffb6c1">
    <div class="header">
        <div class="pic">
            <tr>
                <td align="center" height="120">
                    <img src="image/head.jpg" width="1510" height="120">
                </td>
            </tr>
            <p>顺德职业技术学院同学录</p>
        </div>
    </div>
    <div class="second" style="background-color: skyblue">
        <div style="float: left">
            <a href="https://www.baidu.com">首页</a>
        </div>
        <div class="time">
            <? $datetime= date("Y-m-d H:i:s");
            echo $datetime;
            ?>
        </div>
    </div>

</body>
</head>
</html>
