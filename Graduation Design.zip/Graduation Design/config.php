<?php
$DBHOST='localhost';
$DBUSER='root';
$DBPWD='root';
$DBNAME='alumni';
$NAME='顺德职业技术学院同学录';
