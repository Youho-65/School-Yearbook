<?php
$connection=mysqli_connect($DBHOST,$DBUSER,$DBPWD);
$conn=mysqli_select_db($connection,$DBNAME) ;