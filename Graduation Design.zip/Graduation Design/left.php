<?
include "config.php";//包含系统匹配文件
$classid=$_GET['classid'];//获取地址栏传递的参数classid
$id=$_SESSION['userid'];//从session获取userid的值
$username=$_SESSION['username'];//从session获取username的值
?>

<td width="140" valign="top" align="center">
    <table width="98%" border="0" cellspacing="0" cellpadding="3">
        <tr><!--第一行-->
            <td valign="top" align="center">
                <table width="98%" border="1" cellspacing="0" cellpadding="3" bordercolorlight="#4876FF"  bordercolordark="#4876FF">
                    <tr>
                        <td>班级工具栏</td>
                    </tr>
                    <tr>
                        <td valign="top" align="center">
                            <table width="95%" border="0" cellspacing="0" cellpadding="3">
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">班&nbsp级&nbsp留&nbsp言</a></td>
                                </tr>
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">班&nbsp级&nbsp读&nbsp物</a></td>
                                </tr>
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">班&nbsp级&nbsp相&nbsp册</a></td>
                                </tr>
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">班&nbsp级&nbsp成&nbsp员</a></td>
                                </tr>
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">修&nbsp改&nbsp信&nbsp息</a></td>
                                </tr>
                                <tr>
                                    <td align="center"><a href="http://www.wanmeikk.me/">修&nbsp改&nbsp密&nbsp码</a></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr><!--第二行-->
                        <td align="center">你好,<?echo $_SESSION['username']?>!</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

</td>