<?php
include "head.php";
if(isset($_POST['username']) &&  isset($_POST['passwd'])){
    $name = $_POST['username'];
    $pass = $_POST['passwd'];
// echo $name;
// echo $pass;
    $db= mysqli_connect("localhost","root","root","alumni");//连接数据库
    $sql =" select * from tb_user where username  = '$name' ";
    $res = mysqli_query($db,$sql);//执行数据库语句
// $row = mysqli_fetch_assoc($res);
    $row = mysqli_fetch_assoc($res);//获取结果
    if($name ==$row["username"] && $pass ==$row["passwd"]){
        echo "<script>alert('登录成功');location.href='reguser.php'</script>";
    }else{
        echo "<script>alert('登录失败');location.href='index.php';</script>";
    }
}
?>

<html>
<head>
<body>
<form action="index.php" method="post">
    <div>用户名:<input type="text" class="username" name="username"></div>
    <br>
    <div>密码:<input type="password" class="passwd" name="passwd"></div>
    <br>
    <div><input type="submit" name="login" value="login"></div>
</form>
</body>
</head>
</html>
